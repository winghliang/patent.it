inventionApp.config(function($routeProvider){

    $routeProvider
        .when('/', {
            templateUrl: 'partials/inventor_dash.html'
        })
        .otherwise({
            redirectTo: '/'
        })

})