inventionApp.config(function($routeProvider){

    $routeProvider
        .when('/', {
            templateUrl: 'partials/prosecutor_dash.html'
        })
        .otherwise({
            redirectTo: '/'
        })

})