inventionApp.controller('ProsecutorsController', function($scope, ProsecutorFactory){

	$scope.prosecutors = [];

	// InventorFactory.index(function(data){
	// 	console.log(data);
	// 	$scope.inventors = data;
	// })

})